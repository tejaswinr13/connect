package com.example.kafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class KafkaApplicationTests {

    @Test
    public void contextLoads() {
    }

}
