//package com.example.kafka.test;
//
//import org.apache.commons.text.StringEscapeUtils;
//
//
//public class StringSanitization {
//
//    public static String sanitizeString(String input) throws IllegalArgumentException {
//        // Check if the input is null or empty.
//        if (input == null || input.isEmpty()) {
//            throw new IllegalArgumentException("Input string cannot be null or empty.");
//        }
//
//        // Escape any HTML special characters in the input.
//        String escapedInput = StringEscapeUtils.escapeHtml4(input);
//
//        // Check if the escaped input is valid.
//        if (!escapedInput.matches("[a-zA-Z0-9_.@\\-]+")) {
//            throw new IllegalArgumentException("Input string contains invalid characters.");
//        }
//
//        return escapedInput;
//    }
//
//    public static void main(String[] args) {
//        String input = "\"my-string;alert('Malicious code');\"";
//        String sanitizedInput = sanitizeString(input);
//        System.out.println(sanitizedInput); // my-valid-string
//
//        input = "\"my-string;alert('Malicious code');\"";
//        try {
//            sanitizedInput = sanitizeString(input);
//        } catch (IllegalArgumentException e) {
//            System.out.println(e.getMessage()); // Input string contains invalid characters.
//        }
//    }
//}
