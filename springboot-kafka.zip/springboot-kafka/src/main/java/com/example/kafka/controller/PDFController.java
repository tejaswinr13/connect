package com.example.kafka.controller;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;

@RestController
@RequestMapping("/api")
public class PDFController {

    @Autowired
    private KafkaTemplate<String,String> kafkaTemplate;
    private static final String TOPIC_NAME = "kv-topic";

    private final StringBuilder combinedChunks = new StringBuilder();


    @PostMapping("/upload")
    public String uploadPdf(@RequestParam("file") MultipartFile file) throws IOException {
        if (file.isEmpty()) {
            return "File is empty";
        }

        String uuidKey = UUID.randomUUID().toString();
        byte[] pdfBytes = file.getBytes();

        // Convert PDF to Base64
        String base64EncodedPdf = Base64.getEncoder().encodeToString(pdfBytes);

        // Split PDF if size exceeds 1MB
        int chunkSize = 1 * 1024 * 1024; // 1MB
        int totalChunks = (int) Math.ceil((double) pdfBytes.length / chunkSize);

        for (int i = 0; i < totalChunks; i++) {
            int fromIndex = i * chunkSize;
            int toIndex = Math.min((i + 1) * chunkSize, pdfBytes.length);
            byte[] chunkBytes = new byte[toIndex - fromIndex];
            System.arraycopy(pdfBytes, fromIndex, chunkBytes, 0, toIndex - fromIndex);

            // Create key based on the original filename and chunk index
           // String key = originalFilename + "_" + i;

            // Convert chunk to Base64
            String base64EncodedChunk = Base64.getEncoder().encodeToString(chunkBytes);

            // Send chunk to Kafka
            kafkaTemplate.send(TOPIC_NAME, uuidKey, base64EncodedChunk);
        }
        //To have the difference
        kafkaTemplate.send(TOPIC_NAME, UUID.randomUUID().toString(), "");
        return "PDF uploaded and processed successfully.";
    }
    //@KafkaListener(topics = TOPIC_NAME, groupId = "group_id")
    private String currentKey = null;
    private StringBuilder currentValue = new StringBuilder();

    private final Map<String, StringBuilder> pdfChunks = new HashMap<>();

    @Value("${pdf.output.directory}")
    private String pdfOutputDirectory;

    @KafkaListener(topics = TOPIC_NAME, groupId = "pdf_group")
    public void listen(ConsumerRecord<String, String> record) {
        String key = record.key();
        String value = record.value();

        if (value.isEmpty()) {
            // End of PDF, process and reset
            processKeyValues();
            return;
        }

// Ignore padding issues using Base64.Decoder
        String base64String = value.replaceAll("=+$", "");
        Base64.Decoder decoder = Base64.getDecoder();
        byte[] decodedPdfBytes = decoder.decode(base64String.getBytes(StandardCharsets.UTF_8));

        // Continue with the existing logic
        if (!key.equals(currentKey)) {
            processKeyValues();
            currentKey = key;
            currentValue = new StringBuilder(new String(decodedPdfBytes, StandardCharsets.UTF_8));
        } else {
            currentValue.append(new String(decodedPdfBytes, StandardCharsets.UTF_8));
        }
    }

    private void processKeyValues() {
        if (currentKey != null && currentValue.length() > 0) {
            // Save the combined PDF to a location
            saveCombinedPdf(currentKey, currentValue.toString());
            // Reset current values for the next key
            currentValue.setLength(0);
        }
    }

    private void saveCombinedPdf(String key, String combinedPdfContent) {
        byte[] decodedPdfBytes = Base64.getDecoder().decode(combinedPdfContent.trim());
        String outputPath = pdfOutputDirectory + "/" + key + ".zip";

        try (FileOutputStream outputStream = new FileOutputStream(outputPath)) {
            outputStream.write(decodedPdfBytes);
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Combined PDF saved to: " + outputPath);
    }
    private String addPadding(String base64String) {
        int padding = 4 - base64String.length() % 4;
        StringBuilder paddedBase64 = new StringBuilder(base64String);
        for (int i = 0; i < padding; i++) {
            paddedBase64.append("=");
        }
        return paddedBase64.toString();
    }

}
