package com.example.kafka.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class Person {
    private Long id;
    private String firstName;
    private String lastName;
}
