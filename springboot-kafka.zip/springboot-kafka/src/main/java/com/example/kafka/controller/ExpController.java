package com.example.kafka.controller;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;
import java.util.Base64;

import java.util.*;

@RestController
@RequestMapping("/api")
public class ExpController {

    @Autowired
    private KafkaTemplate<String,String> kafkaTemplate;
    private static final String TOPIC_NAME = "kv-topic";

    private final StringBuilder combinedChunks = new StringBuilder();


    @PostMapping("/sendToKafka")
    public String sendToKafka(@RequestBody List<Map<String, String>> keyValuePairs) {
        for (Map<String, String> entry : keyValuePairs) {
            if (entry.containsKey("key") && entry.containsKey("value")) {
                String key = entry.get("key");
                String value = entry.get("value");
                String encodedStringValue = Base64.getEncoder().encodeToString(value.getBytes());
                // Send the key-value pair to Kafka topic
                System.out.println("encode :: "+encodedStringValue);
                kafkaTemplate.send(TOPIC_NAME, key, encodedStringValue);
            }
        }

        return "Key-Value pairs sent to Kafka";
    }
    //@KafkaListener(topics = TOPIC_NAME, groupId = "group_id")
    private String currentKey = null;
    private StringBuilder currentValue = new StringBuilder();

    //@KafkaListener(topics = TOPIC_NAME, groupId = "group_id")
    public void listen(ConsumerRecord<String, String> record) {
        String key = record.key();
        String value = record.value();

        if ((currentKey == null || !currentKey.equals(key))&&value!=null) {
            // New key found, process the previous key and start a new one
            processKeyValues();
            currentKey = key;
            byte[] decodedBytes = Base64.getDecoder().decode(value);
            String decodedStringValue = new String(decodedBytes);
            currentValue = new StringBuilder(decodedStringValue);
        } else {
            // Same key, append the value
            byte[] decodedBytes = Base64.getDecoder().decode(value);
            String decodedStringValue = new String(decodedBytes);
            currentValue.append(decodedStringValue);
        }
    }

    // Process the key and its values
    private void processKeyValues() {
        if (currentKey != null && currentValue.length()>0) {
            System.out.println("Key: " + currentKey + ", Aggregated Value: " + currentValue.toString());
        }
    }

}
