//package com.example.kafka.service;
//
//public interface KafkaProducerService {
//
//    void send(String message);
//}