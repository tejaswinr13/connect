package com.example.kafka.controller;

import com.example.kafka.service.KafkaProducerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/kafka")
public class KafkaController {

    @Autowired
    private KafkaTemplate<String,String> kafkaTemplate;

    @GetMapping(value = "/sendp/{message}")
    public String send(@PathVariable String message){
        System.out.printf("11111111111");
        kafkaTemplate.send("test-one","########## oitospot7 ##########");
        return "ok";
    }
}
