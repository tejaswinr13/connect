package com.example.kafka.controller;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;

import java.io.*;
import java.util.UUID;

@RestController
@RequestMapping("/kafka")
public class KafkaController {

    @Autowired
    private KafkaTemplate<String,String> kafkaTemplate;
    private static final String TOPIC_NAME = "csv-topic-600mb";
    private static final long MAX_CHUNK_SIZE = 200 * 1024 * 1024;

    private final StringBuilder combinedChunks = new StringBuilder();


    @GetMapping(value = "/sendp")
    public String send(){
        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/tejaswinrenugunta/Downloads/springboot-examples-main/springboot-kafka/src/main/resources/176mb.zip"))) {

            String line;
            StringBuilder chunk = new StringBuilder();
            long chunkSize = 0;

            while ((line = reader.readLine()) != null) {
                chunk.append(line).append("\n");
                chunkSize += line.length();

                if (chunkSize >= MAX_CHUNK_SIZE) {
                    kafkaTemplate.send(TOPIC_NAME, chunk.toString());
                    chunk.setLength(0);
                    chunkSize = 0;
                }
            }

            // Send the last chunk
            if (chunk.length() > 0) {
                kafkaTemplate.send(TOPIC_NAME, chunk.toString());
            }
            return "file inserted to topic :: "+TOPIC_NAME;
        } catch (Exception e) {
            e.printStackTrace();
            return "FAILED to insert data to exception :: "+e.getMessage();
        }

    }
   @KafkaListener(
            topics = TOPIC_NAME,
            containerFactory = "kafkaListenerContainerFactory",
            groupId = "csv-consumer-group1"
    )
    public void listen(String record) {
        // Concatenate the received chunk
        combinedChunks.append(record);

        // Optionally, process the complete CSV file when all chunks are received
        if (isLastChunk(record)) {

        String outputPath="/Users/tejaswinrenugunta/Downloads/springboot-examples-main/springboot-kafka/src/main/resources/output.csv";
            writeCombinedCsvToFile(combinedChunks.toString(),outputPath);
            combinedChunks.setLength(0); // Clear the buffer for the next set of chunks
        }
    }

    private boolean isLastChunk(String record) {
        // Implement a mechanism to identify the last chunk (e.g., based on a specific marker)
        // For simplicity, assuming each message is a chunk
        return true;
    }

    private void writeCombinedCsvToFile(String combinedCsv, String outputPath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputPath))) {
            writer.write(combinedCsv);
            System.out.println("Combined CSV written to file: " + outputPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
