package com.example.kafka.service;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Properties;

public class CsvKafkaProducerConsumer {

    private static final String TOPIC_NAME = "csv-topic";


    private static void produceCsvToKafka(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            Properties properties = new Properties();
            properties.put("bootstrap.servers", "localhost:9092");
            properties.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
            properties.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

            Producer<String, String> producer = new KafkaProducer<>(properties);

            String line;
            StringBuilder chunk = new StringBuilder();
            long chunkSize = 0;
            long maxSize = 8 * 1024 * 1024; // 8MB

            while ((line = reader.readLine()) != null) {
                chunk.append(line).append("\n");
                chunkSize += line.length();

                if (chunkSize >= maxSize) {
                    producer.send(new ProducerRecord<>(TOPIC_NAME, chunk.toString()));
                    chunk.setLength(0);
                    chunkSize = 0;
                }
            }

            // Send the last chunk
            if (chunk.length() > 0) {
                producer.send(new ProducerRecord<>(TOPIC_NAME, chunk.toString()));
            }

            producer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
