//package com.example.kafka.service;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.messaging.handler.annotation.Payload;
//import org.springframework.stereotype.Service;
//
//@Service
//public class KafkaConsumerServiceImpl implements KafkaConsumerService {
//
//    private static final Logger logger = LoggerFactory.getLogger(KafkaConsumerServiceImpl.class);
////3P-->1T
//    @KafkaListener(topics = {"oitospot"
//            ,"oitospot2"
//            ,"oitospot3"
//            ,"oitospot4"
//            ,"oitospot5"
//            ,"oitospot6"
//            ,"oitospot7"},
//    containerFactory = "kafkaListenerContainerFactory",
//    groupId = "group-1")
//    public void receive(@Payload String message) {
//        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ consumer @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
//
//        //logic
//
//        logger.info("message received: {}", message);
//    }
//}