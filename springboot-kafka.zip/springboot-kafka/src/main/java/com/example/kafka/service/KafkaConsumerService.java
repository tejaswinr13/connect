//package com.example.kafka.service;
//
//public interface KafkaConsumerService {
//
//    void receive(String message);
//}